#!/usr/bin/bash

echo "Building backend image"
docker build -t croz-backend server
echo "Built the backend image"

echo "Building frontend image"
docker build -t croz-frontend client
echo "Built the fronted image"

echo "Starting backend service"
helm install backend backend/ --values backend/values.yaml

echo "Starting frontend service"
helm install frontend frontend/ --values frontend/values.yaml
